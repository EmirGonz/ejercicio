package programacion;

public class ejercicio13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		        double a = 2.0; // Valor de a
		        double b = -4.0; // Valor de b

		        double x = -b / a; // Calculamos la solución

		        System.out.println("La solución de la ecuación " + a + "x + " + b + " = 0 es x = " + x);
		    }
		}


	


