package programacion;

import java.util.Scanner;

public class ejercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//formula p=2*pi*r
		Scanner tc= new Scanner(System.in);
		
		double p,r;
		int x=2;
		double pi=3.1416;
		
		System.out.println("Ingresar el valor del radio de la circunferencia");
		r=tc.nextDouble();
		
		//Operacion 
		
		p=(int)((int)x*pi*r);
		
		System.out.println("Su valor del perimetro de la circunferencia es "+p);
		
		
		

	}

}
