package programacion;

import java.util.Scanner;

public class ejercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc= new Scanner (System.in);
		 
		System.out.println("cual es la altura");
		double altura =tc.nextDouble();
		
		System.out.println("cual es la base");
		double base =tc.nextDouble();
		double area_rectangulo =0;
		
		
		area_rectangulo =base*altura;
		 
		System.out.println("El area de un rectangulo de base "+ base +" y altura "+ altura +" es igual a "+ area_rectangulo );

	}

}
