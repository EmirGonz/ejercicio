package programacion;

import java.util.Scanner;

public class ejercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc= new Scanner(System.in);
		
		double y;
		double x;
		double c=2.5;
		double constante=2;
		
		System.out.println("Ingrese el valor de x");
		x=tc.nextInt();
		
		y=x*c-constante;
		
		System.out.println("El Calculo de la formula Y=X*C-2 donde x="+ x +" es "+ y);

	}

}
