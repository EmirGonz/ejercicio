package programacion;

import java.util.Scanner;

public class ejercicio4 {

	public static void main(String[] args) {
		// TODO Auto-generated method 
		Scanner tc= new Scanner(System.in);
		
		
		System.out.println("Calcula la raiz cuadrada de ");
		double numero1 =tc.nextDouble();
		double raiz1 = Math.sqrt(numero1);
		
		System.out.println("La raiz cuadrada de "+ numero1 +" es "+ raiz1);


	}

}
