package programacion;

import java.util.Scanner;

public class ejercicio5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc= new Scanner(System.in);
		
		System.out.println("Kilogramos:");
		int x = tc.nextInt();
		 int y = 11/5;
		 
		 int p = prom (x,y);
		 System.out.println("Son "+ p +" Libras aproximadamente ");

	}

	private static int prom(int q, int w) {
		// TODO Auto-generated method stub
		return (q*w);
	}

}
