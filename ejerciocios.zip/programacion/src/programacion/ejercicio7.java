package programacion;

import java.util.Scanner;

public class ejercicio7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc= new Scanner(System.in);
		  
		System.out.println("Ingrese la longitud del lado a: ");
		double a =tc.nextDouble();
		
		System.out.println("Ingrese la longitud del lado b: ");
		double b =tc.nextDouble();
		
		System.out.println("Ingrese la longitud del lado c: ");
		double c =tc.nextDouble();

		double s = (a+b+c)/ 2; //semiperimetro
		double area=Math.sqrt(s*(s-a)*(s-b)*(s-c));
		
		System.out.println("El area del triangulo es: "+ area);

	}

}
