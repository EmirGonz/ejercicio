package programacion;

import java.util.Scanner;

public class ejercicio6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc= new Scanner(System.in);
		
		System.out.println("Ingrese el grado fahrenheit");
		double fahrenheit =tc.nextDouble();
		
		double celsius = 5.0 / 9.0 * (fahrenheit - 32.0);
		System.out.println(fahrenheit+" grados Fahrenheit equivale a "+ celsius +" grados Celsius");

	}

}
