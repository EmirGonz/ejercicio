package programacion;

import java.util.Scanner;

public class ejercicio8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc= new Scanner(System.in);
		
		float radio = 2.5f;
		float altura = 5.0f;
		double volumen = calcularVolumenCilindro(radio,altura);
		System.out.println("el volumen del cilindro es: "+ volumen);

	}

	private static double calcularVolumenCilindro(float radio, float altura) {
		// TODO Auto-generated method stub
		double pi =3.1416;
		double volumen = pi * Math.pow(radio,2) * altura;
		return volumen;
	}

}
