package programacion;

import java.util.Scanner;

public class ejercicio14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc= new Scanner(System.in);

		        int[][] matriz = {{1, 2}, {3, 4}}; // Matriz de segundo grado
		        int determinante = (matriz[0][0] * matriz[1][1]) - (matriz[0][1] * matriz[1][0]); // Cálculo del determinante
		        System.out.println("El determinante de la matriz es: " + determinante);
		    }
		}


	


