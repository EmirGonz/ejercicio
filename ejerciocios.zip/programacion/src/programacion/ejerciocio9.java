package programacion;

import java.util.Scanner;

public class ejerciocio9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double masa = 10.0; // Asignamos un valor de 10.0 kg para la masa
		double aceleracion = 5.0; // Asignamos un valor de 5.0 m/s^2 para la aceleración
		double fuerza = masa * aceleracion; // Calculamos la fuerza usando la fórmula de la Segunda Ley de Newton

		System.out.println("El valor de la fuerza es: " + fuerza + " N"); // Mostramos el resultado en la consola


	}

}
