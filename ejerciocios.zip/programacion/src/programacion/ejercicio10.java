package programacion;

import java.util.Scanner;

public class ejercicio10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc= new Scanner(System.in);
		
		System.out.println("Ingrese el numero para determinar su Coseno: ");
		double numero =tc.nextDouble();  // número del cual se quiere obtener el coseno
		double coseno = Math.cos(numero); // se calcula el coseno del número
		System.out.println("El coseno de " + numero + " es " + coseno); // se imprime el resultado


	}

}
