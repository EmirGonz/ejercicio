package programacion;

import java.util.Scanner;

public class ejercicio11 {
    public static void main(String[] args) {
        Scanner tc = new Scanner(System.in);

        System.out.print("Ingresa la cantidad de notas: ");
        int n = tc.nextInt();

        double suma = 0;
        double nota;

        for (int i = 0; i < n; i++) {
            System.out.print("Ingresa la nota " + (i + 1) + ": ");
            nota = tc.nextDouble();
            suma += nota;
        }

        double promedio = suma / n;
        System.out.println("El promedio de las " + n + " notas es: " + promedio);

        tc.close();
    }
}

		    
		


	


