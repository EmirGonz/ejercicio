package programacion;

import java.util.Scanner;

public class ejercicio12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner tc = new Scanner(System.in);

		      System.out.print("Ingrese el número de yardas: ");
		      double yardas = tc.nextDouble();

		      System.out.print("Ingrese el número de pies: ");
		      double pies = tc.nextDouble();

		      System.out.print("Ingrese el número de pulgadas: ");
		      double pulgadas = tc.nextDouble();

		      double totalCentimetros = (yardas * 91.44) + (pies * 30.48) + (pulgadas * 2.54);

		      System.out.println(yardas + " yardas, " + pies + " pies, y " + pulgadas + " pulgadas equivale a " + totalCentimetros + " centimetros.");
		   }
		}


	


